# PizzaHub — Student Food Ordering Website

This is a four-page responsive student project website:
- index.html — Home
- menu.html — Pizza Menu
- checkout.html — Order & Checkout
- contact.html — Delivery & Contact
- style.css — Styling and responsive layout
- script.js — Menu filtering, cart, checkout demo and localStorage

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload all files in this folder to the repository root.
3. Go to Settings → Pages.
4. Choose "Deploy from a branch".
5. Select the main branch and `/root`.
6. Save and wait for GitHub Pages to publish the site.

Note: The checkout is a prototype/demo. It does not process real payments.
