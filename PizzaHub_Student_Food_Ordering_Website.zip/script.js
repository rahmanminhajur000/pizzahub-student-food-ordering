
const products = [
  {id:1,name:"Margherita Pizza",price:8.99,cat:"Classic",emoji:"🍕",desc:"Classic cheese & tomato sauce"},
  {id:2,name:"Pepperoni Pizza",price:10.99,cat:"Classic",emoji:"🍕",desc:"Pepperoni, cheese, tomato sauce"},
  {id:3,name:"BBQ Chicken Pizza",price:11.99,cat:"Meat Lovers",emoji:"🍕",desc:"BBQ sauce, chicken, onions"},
  {id:4,name:"Veggie Delight",price:9.99,cat:"Veggie",emoji:"🍕",desc:"Fresh vegetables & cheese"},
  {id:5,name:"Hawaiian Pizza",price:10.49,cat:"Special",emoji:"🍕",desc:"Ham, pineapple, cheese"},
  {id:6,name:"Meat Lovers",price:12.99,cat:"Meat Lovers",emoji:"🍕",desc:"Pepperoni, sausage, bacon"}
];

function getCart(){return JSON.parse(localStorage.getItem("pizzaCart")||"[]")}
function saveCart(cart){localStorage.setItem("pizzaCart",JSON.stringify(cart))}
function cartCount(){return getCart().reduce((s,x)=>s+x.qty,0)}
function money(n){return "$"+n.toFixed(2)}
function updateCartBadges(){
  document.querySelectorAll("[data-cart-count]").forEach(el=>el.textContent=cartCount())
}
function addToCart(id){
  const cart=getCart(), item=products.find(p=>p.id===id), existing=cart.find(x=>x.id===id);
  if(existing) existing.qty++; else cart.push({id,qty:1});
  saveCart(cart); updateCartBadges(); toast(item.name+" added to your cart.")
}
function toast(msg){
  const el=document.querySelector(".toast"); if(!el)return;
  el.textContent=msg;el.style.display="block";clearTimeout(window._toast);
  window._toast=setTimeout(()=>el.style.display="none",2200);
}
function productCard(p){
  return `<article class="product-card">
    <div class="product-image">${p.emoji}</div>
    <div class="product-body"><h3>${p.name}</h3><p class="muted small">${p.desc}</p>
    <div class="price">${money(p.price)}</div>
    <button class="btn btn-primary" onclick="addToCart(${p.id})">Add to Cart</button></div>
  </article>`;
}
function renderProducts(list, target){
  const el=document.querySelector(target); if(el)el.innerHTML=list.map(productCard).join("");
}
function renderMenu(){
  const target="#menu-products"; if(!document.querySelector(target))return;
  let current="All";
  const draw=()=>renderProducts(current==="All"?products:products.filter(p=>p.cat===current),target);
  document.querySelectorAll("[data-category]").forEach(btn=>{
    btn.addEventListener("click",()=>{
      current=btn.dataset.category;
      document.querySelectorAll("[data-category]").forEach(b=>b.classList.remove("active"));
      btn.classList.add("active");draw();
    });
  });
  draw();
}
function renderCheckout(){
  const target=document.querySelector("#cart-items"); if(!target)return;
  const cart=getCart();
  if(!cart.length){target.innerHTML='<div class="empty">Your cart is empty. <a class="link" href="menu.html">Browse the menu →</a></div>';document.querySelector("#summary").innerHTML="";return}
  target.innerHTML=cart.map(x=>{
    const p=products.find(q=>q.id===x.id);
    return `<div class="order-row"><div class="order-thumb">${p.emoji}</div>
      <div><strong>${p.name}</strong><div class="muted small">${money(p.price)} each</div></div>
      <div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><strong>${x.qty}</strong><button onclick="changeQty(${p.id},1)">+</button></div>
      <strong>${money(p.price*x.qty)}</strong></div>`;
  }).join("");
  const subtotal=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
  const delivery=subtotal>=25?0:2;
  document.querySelector("#summary").innerHTML=`
    <div class="total-row"><span>Subtotal</span><strong>${money(subtotal)}</strong></div>
    <div class="total-row"><span>Delivery fee</span><strong>${delivery===0?"FREE":money(delivery)}</strong></div>
    <div class="total-row final"><span>Total</span><strong>${money(subtotal+delivery)}</strong></div>`;
}
function changeQty(id,delta){
  const cart=getCart(),item=cart.find(x=>x.id===id); if(!item)return;
  item.qty+=delta;
  saveCart(cart.filter(x=>x.qty>0));updateCartBadges();renderCheckout();
}
function setupCheckout(){
  const form=document.querySelector("#checkout-form");if(!form)return;
  form.addEventListener("submit",e=>{
    e.preventDefault();
    if(!getCart().length){toast("Please add a pizza first.");return}
    saveCart([]);updateCartBadges();renderCheckout();
    form.reset();toast("Order placed successfully! Thank you.");
  });
}
document.addEventListener("DOMContentLoaded",()=>{
  updateCartBadges();renderMenu();renderCheckout();setupCheckout();
  const year=document.querySelector("[data-year]");if(year)year.textContent=new Date().getFullYear();
});
